# Serverless Web Application on AWS

## Project Name: Serverless Web Application on AWS

### Project Description:
#### Steps to follow:
Step1:
1> Create the Book Catalog Webpage:
   <!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>HTML Table</h2>

<table>
  <tr>
    <th>Company</th>
    <th>Contact</th>
    <th>Country</th>
  </tr>
  <tr>
    <td>Alfreds Futterkiste</td>
    <td>Maria Anders</td>
    <td>Germany</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
  <tr>
    <td>Ernst Handel</td>
    <td>Roland Mendel</td>
    <td>Austria</td>
  </tr>
  <tr>
    <td>Island Trading</td>
    <td>Helen Bennett</td>
    <td>UK</td>
  </tr>
  <tr>
    <td>Laughing Bacchus Winecellars</td>
    <td>Yoshi Tannamuri</td>
    <td>Canada</td>
  </tr>
  <tr>
    <td>Magazzini Alimentari Riuniti</td>
    <td>Giovanni Rovelli</td>
    <td>Italy</td>
  </tr>
</table>

</body>
</html>


2> Save the HTML File:
  Save the HTML file with a html extension for example index.html
3> Create vpc:
  i> Sign in to your AWS Mangament Console
  ii> Open the vpc Console
  iii> Create vpc 
  iv> Create subnets as needed
  v> Then create Internet Gateway and make sure that to attach to vpc that we created
  vi> Then edit the route table
4> Create EC2:
 i> Open the ec2 Console
 ii> Create instance and select AMI, instance type and create key pair
 iii> Now edit the network settings
      a) Create security groups
      b)Now click on edit button
      c)Then select the vpc and subtnet
      d)Make sure that make ip address as public
      e)Finally create instance
5> Create an AWS S3 console
 i> Open the Amazon S3 console.
 ii> Click the "create bucket" button, and choose a globally unique bucket name and select the region for your bucket.
 iii> Choose object ownership as Enable.
 iv> Choose all blocked public access settings for the bucket and set back to enable all listed permissions and acknowledge that permissions are open to host website files in public.
 v> Click " create bucket "
 vi> Now acess the newly created bucket and upload webiste in bucket.
 vii> Upload the book catalogue webpage(index.html).
 viii> Access bucket properties and enable public webhosting.
 ix> After enable " static webhosting " do mention index.html and error.html.
 x> Copy the object url and paste it chrome 
 xi> Finally web application has been excuted.



 