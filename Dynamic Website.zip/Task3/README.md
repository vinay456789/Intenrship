# Serverless Web Application on AWS

## Project Name: Hosting Dynamic Website

### Project Description:
#### Steps to follow:
1> Create vpc:
  i> Sign in to your AWS Mangament Console
  ii> Open the vpc Console
  iii> Create vpc 
  iv> Create subnets as needed
  v> Then create Internet Gateway and make sure that to attach to vpc that we created
  vi> Then edit the route table
2> Create EC2:
 i> Open the ec2 Console
 ii> Create instance and select AMI, instance type and create key pair
 iii> Now edit the network settings
      a)Create security groups
      b)Now click on edit button
      c)Then select the vpc and subtnet
      d)Make sure that make ip address as public
      e)Finally create instance
3> Connect instance to excute
4> Commands to excute
  i)sudo su
  ii)pwd
  iii)yum update -y
  iv)yum install httpd -y
  v)systemctl httpd on
  vi)systemctl start httpd
  vii)systemctl status httpd
  viii)chkconfig httpd on
  ix)cd /var/www/html/
  x) echo "
           <html>
             <body>
               <h1 align='center'> ONLINE BOOK STORE WEBSITE </h1>
             </body>
          </html>" >index.html  