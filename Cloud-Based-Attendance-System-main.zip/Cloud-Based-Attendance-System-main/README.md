# Cloud-Based-Attendance-System
Created a cloud based attendence system for Information Storage and Management project using php, html and css
