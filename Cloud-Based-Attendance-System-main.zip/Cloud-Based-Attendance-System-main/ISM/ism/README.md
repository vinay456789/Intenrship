# Student Attendance Management System in PHP

This is a Online Student Attendance Management System in PHP, created by Mahmudul Hassan with the massive support and involvement of the community.

## Installation & Usage

```python
Download the zip file, then extract it to your localhost.
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
This project is released under the [MIT](https://choosealicense.com/licenses/mit/) license.
